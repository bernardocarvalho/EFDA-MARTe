#ifndef MINGAMOUTPUTSTRUCTURE_H_
#define MINGAMOUTPUTSTRUCTURE_H_

#include "System.h"

struct MinimalGAMOutputStructure {
    /** Output of the minimal GAM */
    bool                  outvar;

};

#endif 